#U1
import tkinter
from datetime import datetime 

canvas = tkinter.Canvas(width=640,height=480)
canvas.pack()

time_id = canvas.create_text(640//2,480//2,text=" ") 
def get_time():
    return datetime.now().strftime("%H:%M:%S")
def watches():
    canvas.itemconfig(time_id,text=datetime.now().strftime("%H:%M:%S"))
    canvas.after(1000,watches)
        

watches()
                            
canvas.mainloop()


