import tkinter

canvas = tkinter.Canvas(width=640,height=480)
canvas.pack()

smer = 1
stav = 2
rect_id = canvas.create_rectangle(640//2-35,480//2-35,640//2+35,480//2+35,
                                  fill="firebrick",outline="firebrick")
def move():
    global smer
    x1,y1,x2,y2=canvas.coords(rect_id)
    if y1 <= 0:
        smer = 1
    elif y2 >= 480:
        smer = -1
    canvas.move(rect_id,0,smer*3)
    if stav ==1:
        canvas.after(10,move)
def klik(event):
    global stav
    if stav == 1:
        stav = 2
    elif stav ==2:
        stav = 1
        move()
        
         
        
       
canvas.bind("<ButtonPress-1>",klik)

canvas.mainloop()
