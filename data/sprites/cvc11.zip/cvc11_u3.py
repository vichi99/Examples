import tkinter
import random

canvas = tkinter.Canvas(width=640,height=480,bg="grey18")
canvas.pack()

def game_start():
    canvas.itemconfig(start_id,text="Hra sa zacina za: {}".format(sekundy))
def start():
    global start_id 
    global sekundy
    for i in range(5):
        canvas.after(1000)
        canvas.update()
        sekundy -= 1
        game_start()
    canvas.after(500)
    canvas.delete(start_id)
    

def tik():
    global oval_id
    global x
    global y
    x = random.randint(1+polomer,640-polomer)
    y = random.randint(1+polomer,480-polomer) 
    canvas.coords(oval_id,x+polomer,y+polomer,x-polomer,y-polomer)
    canvas.update()
    canvas.after(interval,tik)

skore = 0
skore_id = canvas.create_text(550,470,text="Tvoje skore je: {:02d}".format(skore),
                              fill="lime",font="Arial 14")
def score_text():
    canvas.itemconfig(skore_id,text="Tvoje skore je: {:02d}".format(skore))    
def score(event):
    global skore
    global oval_id
    x1,y1,x2,y2 = canvas.coords(oval_id)
    if event.x >= x1 and event.x <= x2 and event.y >= y1 and event.y <= y2:
        canvas.itemconfig(oval_id,fill="green")
        canvas.update()
        canvas.after(100)
        canvas.itemconfig(oval_id,fill="white")
        canvas.update()
        skore += 1
        score_text()
        
    else:
        canvas.itemconfig(oval_id,fill="red")
        canvas.update()
        canvas.after(100)
        canvas.itemconfig(oval_id,fill="white") 
        canvas.update()
        skore -= 1
        score_text()

polomer = int(input("Zadaj polomer kruhu"))
interval = int(input("Zadaj interval zobrazenia kruhu"))
sekundy = 5
start_id = canvas.create_text(640/2,480/2,text="Hra sa zacina za: {}".format
                              (sekundy),fill="yellow",font="Arial 16")
start()
x = random.randint(1+polomer,640-polomer)
y = random.randint(1+polomer,480-polomer)
oval_id = canvas.create_oval(x-polomer,y-polomer,x+polomer,y+polomer,outline="white",
                            fill="white")
tik()
canvas.bind("<ButtonPress-1>",score)

canvas.mainloop()
